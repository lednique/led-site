"""
LED Contact Bot — Telegram bot + API endpoint for collecting commission requests
from lednique.ru and forwarding them to the admin's Telegram.
"""

import asyncio
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

import requests as http_requests
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, EmailStr, field_validator

import config

# ---------- Logging ----------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("ledcontact")

# ---------- Data models ----------
class CommissionRequest(BaseModel):
    name: str
    email: str
    message: str

    @field_validator("name", "message")
    @classmethod
    def not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Field cannot be empty")
        return v.strip()

    @field_validator("email")
    @classmethod
    def valid_email(cls, v: str) -> str:
        if "@" not in v or "." not in v:
            raise ValueError("Invalid email address")
        return v.strip().lower()


# ---------- Telegram helper ----------
def send_telegram_notification(data: CommissionRequest) -> bool:
    """Send a nicely formatted commission request to the admin chat."""
    chat_id = config.ADMIN_CHAT_ID
    if not chat_id:
        logger.warning("ADMIN_CHAT_ID not set — cannot send notification")
        return False

    text = (
        "✨ <b>Новая заявка с сайта!</b>\n\n"
        f"👤 <b>Имя:</b> {data.name}\n"
        f"📧 <b>Email:</b> {data.email}\n"
        f"💬 <b>Сообщение:</b>\n{data.message}\n\n"
        f"🕐 {datetime.now(timezone.utc).strftime('%d.%m.%Y %H:%M UTC')}"
    )

    url = f"https://api.telegram.org/bot{config.BOT_TOKEN}/sendMessage"

    try:
        resp = http_requests.post(
            url,
            json={
                "chat_id": chat_id,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            },
            timeout=15,
        )
        if resp.status_code == 200:
            logger.info(f"Notification sent to chat {chat_id}")
            return True
        else:
            logger.error(
                f"Telegram API error: {resp.status_code} {resp.text}"
            )
            return False
    except Exception as e:
        logger.error(f"Failed to send Telegram notification: {e}")
        return False


# ---------- Store submissions locally (backup) ----------
SUBMISSIONS_FILE = Path("/home/user/ledcontact-bot/submissions.json")

def save_submission(data: CommissionRequest):
    """Append submission to a local JSON file as backup."""
    if SUBMISSIONS_FILE.exists():
        with open(SUBMISSIONS_FILE, "r") as f:
            subs = json.load(f)
    else:
        subs = []

    subs.append({
        "name": data.name,
        "email": data.email,
        "message": data.message,
        "received_at": datetime.now(timezone.utc).isoformat(),
    })

    with open(SUBMISSIONS_FILE, "w") as f:
        json.dump(subs, f, indent=2, ensure_ascii=False)


# ---------- FastAPI app ----------
app = FastAPI(
    title="LED Contact Bot API",
    description="Collects commission requests from lednique.ru and forwards them to Telegram",
    version="1.0.0",
)

# CORS — allow the frontend site to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["POST", "OPTIONS"],
    allow_headers=["Content-Type"],
)


@app.get("/")
async def root():
    return {"status": "ok", "message": "LED Contact Bot API is running"}


@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "admin_chat_configured": config.ADMIN_CHAT_ID is not None,
    }


@app.post("/api/commission")
async def receive_commission(request: Request, data: CommissionRequest):
    """
    Receive a commission request from the website form.
    Saves it locally and sends a Telegram notification to the admin.
    """
    # Log the incoming request
    client_ip = request.client.host if request.client else "unknown"
    logger.info(
        f"Commission from {data.name} ({data.email}) — IP: {client_ip}"
    )

    # Save to local storage
    save_submission(data)

    # Send Telegram notification
    tg_ok = send_telegram_notification(data)

    return JSONResponse(
        content={
            "success": True,
            "message": "Received. I'll write back.",
            "telegram_notified": tg_ok,
        },
        status_code=200,
    )


# ---------- Endpoint to set admin chat ID ----------
class SetAdminChat(BaseModel):
    chat_id: int


@app.post("/api/set-admin")
async def set_admin(data: SetAdminChat):
    """Set the admin Telegram chat ID (call once)."""
    config.ADMIN_CHAT_ID = data.chat_id
    logger.info(f"Admin chat ID set to {data.chat_id}")

    # Send a test message
    test_ok = send_telegram_notification(
        CommissionRequest(
            name="🔧 System",
            email="system@lednique.ru",
            message="✅ Админ чат настроен! Теперь все новые заявки с сайта будут приходить сюда.",
        )
    )

    return JSONResponse(
        content={
            "success": True,
            "admin_chat_id": data.chat_id,
            "test_message_sent": test_ok,
        }
    )


# ---------- Telegram webhook: listen for /start to get chat_id ----------
UPDATE_ID_FILE = Path("/home/user/ledcontact-bot/last_update_id.txt")


async def poll_telegram_updates():
    """Poll Telegram for incoming messages (like /start) to discover admin's chat_id."""
    logger.info("Starting Telegram polling for admin chat ID discovery...")

    last_id = 0
    if UPDATE_ID_FILE.exists():
        with open(UPDATE_ID_FILE) as f:
            last_id = int(f.read().strip())

    url = f"https://api.telegram.org/bot{config.BOT_TOKEN}/getUpdates"

    while True:
        try:
            resp = http_requests.get(
                url,
                params={"offset": last_id + 1, "timeout": 30},
                timeout=35,
            )
            if resp.status_code != 200:
                await asyncio.sleep(10)
                continue

            updates = resp.json().get("result", [])
            for update in updates:
                update_id = update.get("update_id", 0)
                if update_id > last_id:
                    last_id = update_id
                    with open(UPDATE_ID_FILE, "w") as f:
                        f.write(str(last_id))

                msg = update.get("message") or update.get("my_chat_member", {}).get("chat", {})
                chat_id = None

                if "message" in update:
                    chat_id = update["message"]["chat"]["id"]
                    username = update["message"]["chat"].get("username", "?")
                    text = update["message"].get("text", "")
                    logger.info(
                        f"Got message from chat {chat_id} (@{username}): {text}"
                    )
                elif "my_chat_member" in update:
                    chat_id = update["my_chat_member"]["chat"]["id"]
                    username = update["my_chat_member"]["chat"].get("username", "?")
                    logger.info(
                        f"Bot added to chat {chat_id} (@{username})"
                    )

                if chat_id:
                    # Check if this is our admin
                    if config.ADMIN_CHAT_ID is None:
                        config.ADMIN_CHAT_ID = chat_id
                        logger.info(
                            f"✅ Admin chat ID auto-set to {chat_id}"
                        )
                        # Confirm to admin
                        http_requests.post(
                            f"https://api.telegram.org/bot{config.BOT_TOKEN}/sendMessage",
                            json={
                                "chat_id": chat_id,
                                "text": (
                                    "✅ <b>LED Contact Bot активирован!</b>\n\n"
                                    "Я буду присылать сюда новые заявки с сайта lednique.ru.\n"
                                    "Бот работает и готов принимать заявки 🚀",
                                ),
                                "parse_mode": "HTML",
                            },
                            timeout=10,
                        )

        except Exception as e:
            logger.error(f"Polling error: {e}")

        await asyncio.sleep(2)


# ---------- Startup ----------
@app.on_event("startup")
async def startup():
    # Start background polling for Telegram updates
    asyncio.create_task(poll_telegram_updates())
    logger.info("LED Contact Bot started")


