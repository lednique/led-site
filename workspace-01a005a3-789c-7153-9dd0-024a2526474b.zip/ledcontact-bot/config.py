"""Configuration for LED Contact Bot"""

BOT_TOKEN = "8951052564:AAESYT0jJezz9PbfgneocVd9p4S76feefhk"
# Your Telegram chat ID — will be auto-detected or set manually
ADMIN_CHAT_ID = None  # Will be filled after you message the bot

# Allowed origin for CORS (your site)
ALLOWED_ORIGINS = [
    "https://www.lednique.ru",
    "http://localhost:5173",  # For local dev
]

# Server config
HOST = "0.0.0.0"
PORT = 8000