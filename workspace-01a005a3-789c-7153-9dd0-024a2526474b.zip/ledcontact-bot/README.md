# LED Contact Bot — Инструкция по установке

## 1. Структура проекта

```
ledcontact-bot/
├── main.py              # FastAPI сервер + Telegram бот
├── config.py            # Конфигурация (токен, chat_id)
├── requirements.txt     # Зависимости
├── submissions.json     # Файл с сохранёнными заявками
├── last_update_id.txt   # Служебный файл
└── webhook-snippet.js   # Скрипт для вставки на сайт
```

## 2. Деплой на сервер

### Вариант A: Render.com (рекомендую — бесплатно)

1. Зарегистрируйтесь на [render.com](https://render.com) (через GitHub)
2. Нажмите **New +** → **Web Service**
3. Подключите GitHub репозиторий с этими файлами
4. Настройки:
   - **Name**: `ledcontact-bot`
   - **Runtime**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `uvicorn main:app --host 0.0.0.0 --port 10000`
5. Нажмите **Create Web Service**
6. После деплоя вы получите URL вида: `https://ledcontact-bot.onrender.com`

### Вариант B: Railway.app

1. Зарегистрируйтесь на [railway.app](https://railway.app)
2. Создайте новый проект → Deploy from GitHub
3. Настройки те же

### Вариант C: VPS (свой сервер)

```bash
git clone <ваш-репозиторий>
cd ledcontact-bot
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

## 3. Настройка домена (опционально)

На Render у вас будет URL `https://ledcontact-bot.onrender.com`. 
Можно подключить свой домен (например, `api.lednique.ru`) в настройках Render.

## 4. Интеграция с сайтом

### Способ 1 (простой): Вставка скрипта в index.html

Скопируйте файл `webhook-snippet.js` на ваш сервер и добавьте в `index.html`:

```html
<script src="/ledcontact-integration.js"></script>
```

⚠️ **ВАЖНО**: Перед загрузкой откройте `webhook-snippet.js` и замените:
```js
const API_URL = "http://localhost:8000/api/commission";
```
на ваш реальный URL:
```js
const API_URL = "https://ledcontact-bot.onrender.com/api/commission";
```

### Способ 2 (продвинутый): Изменить React компонент

В вашем React приложении найдите компонент формы (функция `l5` в бандле).
Замените функцию `s` (обработчик submit) на:

```javascript
async function s(o) {
  o.preventDefault();
  
  const form = o.currentTarget;
  const name = form.querySelector('[name="name"]').value.trim();
  const email = form.querySelector('[name="email"]').value.trim();
  const message = form.querySelector('[name="message"]').value.trim();
  
  if (!name || !email || !message) return;
  
  try {
    const response = await fetch('https://ledcontact-bot.onrender.com/api/commission', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, message }),
    });
    const result = await response.json();
    if (result.success) r(true);
  } catch (err) {
    console.error(err);
    alert('Ошибка отправки, попробуйте позже');
  }
}
```

## 5. Проверка работы

1. Заполните форму на сайте и нажмите Send
2. В Telegram придёт уведомление:

```
✨ Новая заявка с сайта!

👤 Имя: Иван
📧 Email: ivan@example.com
💬 Сообщение:
Хочу заказать дизайн для YouTube канала

🕐 15.08.2026 13:30 UTC
```

3. Все заявки также сохраняются в файл `submissions.json` на сервере.

## 6. Безопасность

⚠️ **Никому не передавайте токен бота!** 
Токен уже указан в `config.py`. При деплое на Render/Railway рекомендую вынести его в переменные окружения:

```python
import os
BOT_TOKEN = os.getenv("BOT_TOKEN", "8951052564:AAESYT0jJezz9PbfgneocVd9p4S76feefhk")
```

И установить переменную `BOT_TOKEN` в панели управления Render/Railway.