/**
 * LED Contact Bot — интеграция формы с сайтом
 * 
 * Что это делает:
 * 1. Ждёт появления формы на странице
 * 2. Перехватывает нажатие "Send"
 * 3. Отправляет данные на наш API сервер
 * 4. Показывает "Received. I'll write back." при успехе
 *
 * Как подключить:
 * Добавьте этот скрипт в <head> или перед закрывающим </body>
 * в файле index.html вашего React приложения:
 * 
 *   <script src="/ledcontact-integration.js"></script>
 * 
 * ИЛИ вставьте содержимое этого файла напрямую в index.html
 * внутри тега <script>.
 */

(function () {
  // ⚠️ ЗАМЕНИТЕ НА АДРЕС ВАШЕГО СЕРВЕРА ПОСЛЕ ДЕПЛОЯ
  const API_URL = "http://localhost:8000/api/commission";

  // Функция поиска формы
  function findForm() {
    // Ищем форму по классу или структуре
    const form = document.querySelector("form.glass-form");
    if (form) return form;

    // Fallback: ищем форму с полями name, email, message
    const forms = document.querySelectorAll("form");
    for (const f of forms) {
      const hasName = f.querySelector('[name="name"]');
      const hasEmail = f.querySelector('[name="email"]');
      const hasMessage = f.querySelector('[name="message"]');
      if (hasName && hasEmail && hasMessage) return f;
    }
    return null;
  }

  function setupForm(form) {
    if (form.dataset.ledcontactReady) return;
    form.dataset.ledcontactReady = "true";

    const originalSubmit = form.onsubmit;

    form.addEventListener("submit", async function (event) {
      event.preventDefault();

      const name = form.querySelector('[name="name"]').value.trim();
      const email = form.querySelector('[name="email"]').value.trim();
      const message = form.querySelector('[name="message"]').value.trim();

      if (!name || !email || !message) {
        alert("Please fill all fields");
        return;
      }

      // Disable button
      const btn = form.querySelector(".submit-btn, button[type='submit']");
      if (btn) {
        btn.disabled = true;
        btn.textContent = "Sending...";
      }

      try {
        const response = await fetch(API_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, email, message }),
          mode: "cors",
        });

        const result = await response.json();

        if (result.success) {
          // Показываем сообщение об успехе
          const thanks = document.createElement("p");
          thanks.className = "form-thanks";
          // Определяем язык
          const isRu = window.location.pathname.startsWith("/ru") ||
                       document.documentElement.lang === "ru" ||
                       navigator.language.startsWith("ru");
          thanks.textContent = isRu
            ? "Получено. Я отвечу."
            : "Received. I'll write back.";
          
          form.innerHTML = "";
          form.appendChild(thanks);
        } else {
          throw new Error(result.message || "Unknown error");
        }
      } catch (error) {
        console.error("LED Contact: submission failed", error);
        alert("Failed to send. Please try again later.");
        if (btn) {
          btn.disabled = false;
          btn.textContent = "Send";
        }
      }
    });
  }

  // Наблюдатель за DOM — форма может появиться не сразу (React SPA)
  function init() {
    const form = findForm();
    if (form) {
      setupForm(form);
      return;
    }

    const observer = new MutationObserver(() => {
      const form = findForm();
      if (form) {
        setupForm(form);
        observer.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();